--Insert linked questions Queries
------------------------------------
--Section I and Subsection I - folloup questions
BEGIN TRAN
INSERT INTO DBO.DACFollowupQuestion (ResponseType, FollowupText)
SELECT  ResponseType, FollowupText FROM DBO.DACFollowupQuestion WHERE QID IN(
4124,
4125,
4126,
4127,
4128,
4129,
4130
) ORDER BY QID

--Final IC QIDs
--Update linked question IDs for above inserted records. 
--Note: Auto generated ID may change based environment
--SELECT * FROM dbo.DACFollowupQuestion WHERE QID IS NULL ORDER BY 1 

BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET QID = 4316, LinkedQID = 4317  WHERE FollowupQID = 368
UPDATE DBO.DACFollowupQuestion SET QID = 4316, LinkedQID = 4321  WHERE FollowupQID = 369
UPDATE DBO.DACFollowupQuestion SET QID = 4317, LinkedQID = 4318  WHERE FollowupQID = 370
UPDATE DBO.DACFollowupQuestion SET QID = 4317, LinkedQID = 4321  WHERE FollowupQID = 371
UPDATE DBO.DACFollowupQuestion SET QID = 4318, LinkedQID = 4319  WHERE FollowupQID = 372
UPDATE DBO.DACFollowupQuestion SET QID = 4318, LinkedQID = 4319  WHERE FollowupQID = 373
UPDATE DBO.DACFollowupQuestion SET QID = 4319, LinkedQID = 4320  WHERE FollowupQID = 374
UPDATE DBO.DACFollowupQuestion SET QID = 4319, LinkedQID = 4320  WHERE FollowupQID = 375
UPDATE DBO.DACFollowupQuestion SET QID = 4320, LinkedQID = 4321  WHERE FollowupQID = 376
UPDATE DBO.DACFollowupQuestion SET QID = 4320, LinkedQID = 4321  WHERE FollowupQID = 377
UPDATE DBO.DACFollowupQuestion SET QID = 4321, LinkedQID = 4322  WHERE FollowupQID = 378
UPDATE DBO.DACFollowupQuestion SET QID = 4321, LinkedQID = 4322  WHERE FollowupQID = 379
UPDATE DBO.DACFollowupQuestion SET QID = 4322, LinkedQID = NULL  WHERE FollowupQID = 380
UPDATE DBO.DACFollowupQuestion SET QID = 4322, LinkedQID = NULL  WHERE FollowupQID = 381

--Commit
COMMIT

--4316,
--4317,
--4318,
--4319,
--4320,
--4321,
--4322

--Section I and Subsection II - folloup questions
BEGIN TRAN
INSERT INTO DBO.DACFollowupQuestion (ResponseType, FollowupText)
SELECT  ResponseType, FollowupText FROM DBO.DACFollowupQuestion WHERE QID IN(
4131,
4132,
4133,
4134,
4135,
4136
) ORDER BY QID
COMMIT
--To get newly inserted record ids
--SELECT * FROM dbo.DACFollowupQuestion WHERE QID IS NULL ORDER BY 1 
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET QID = 4323, LinkedQID = 4324  WHERE FollowupQID = 382
UPDATE DBO.DACFollowupQuestion SET QID = 4323, LinkedQID = 4324  WHERE FollowupQID = 383
UPDATE DBO.DACFollowupQuestion SET QID = 4324, LinkedQID = 4325  WHERE FollowupQID = 384
UPDATE DBO.DACFollowupQuestion SET QID = 4324, LinkedQID = 4325  WHERE FollowupQID = 385
UPDATE DBO.DACFollowupQuestion SET QID = 4325, LinkedQID = 4326  WHERE FollowupQID = 386
UPDATE DBO.DACFollowupQuestion SET QID = 4325, LinkedQID = 4326  WHERE FollowupQID = 387
UPDATE DBO.DACFollowupQuestion SET QID = 4326, LinkedQID = 4327  WHERE FollowupQID = 388
UPDATE DBO.DACFollowupQuestion SET QID = 4326, LinkedQID = 4327  WHERE FollowupQID = 389
UPDATE DBO.DACFollowupQuestion SET QID = 4327, LinkedQID = 4328  WHERE FollowupQID = 390
UPDATE DBO.DACFollowupQuestion SET QID = 4327, LinkedQID = NULL  WHERE FollowupQID = 391
UPDATE DBO.DACFollowupQuestion SET QID = 4328, LinkedQID = NULL  WHERE FollowupQID = 392
UPDATE DBO.DACFollowupQuestion SET QID = 4328, LinkedQID = NULL  WHERE FollowupQID = 393
COMMIT

--Section II and Subsection I - folloup questions
BEGIN TRAN
INSERT INTO DBO.DACFollowupQuestion (ResponseType, FollowupText)
--A1 - A6
SELECT  ResponseType, FollowupText FROM DBO.DACFollowupQuestion WHERE QID IN(
4138,
4139,
4140,
4141,
4142,
4143
) ORDER BY QID
COMMIT

--To get newly inserted record ids
--SELECT * FROM dbo.DACFollowupQuestion WHERE QID IS NULL ORDER BY 1 
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET QID = 4330, LinkedQID = 4331  WHERE FollowupQID = 394
UPDATE DBO.DACFollowupQuestion SET QID = 4330, LinkedQID = 4331  WHERE FollowupQID = 395
UPDATE DBO.DACFollowupQuestion SET QID = 4331, LinkedQID = 4332  WHERE FollowupQID = 396
UPDATE DBO.DACFollowupQuestion SET QID = 4331, LinkedQID = 4332  WHERE FollowupQID = 397
UPDATE DBO.DACFollowupQuestion SET QID = 4332, LinkedQID = 4333  WHERE FollowupQID = 398
UPDATE DBO.DACFollowupQuestion SET QID = 4332, LinkedQID = 4333  WHERE FollowupQID = 399
UPDATE DBO.DACFollowupQuestion SET QID = 4333, LinkedQID = 4334  WHERE FollowupQID = 400
UPDATE DBO.DACFollowupQuestion SET QID = 4333, LinkedQID = NULL  WHERE FollowupQID = 401
UPDATE DBO.DACFollowupQuestion SET QID = 4334, LinkedQID = 4335  WHERE FollowupQID = 402
UPDATE DBO.DACFollowupQuestion SET QID = 4334, LinkedQID = 4335  WHERE FollowupQID = 403
UPDATE DBO.DACFollowupQuestion SET QID = 4335, LinkedQID = NULL  WHERE FollowupQID = 404
UPDATE DBO.DACFollowupQuestion SET QID = 4335, LinkedQID = NULL  WHERE FollowupQID = 405
COMMIT

--Section II and Subsection II - folloup questions
BEGIN TRAN
INSERT INTO DBO.DACFollowupQuestion (ResponseType, FollowupText)
--B1-B5
SELECT  ResponseType, FollowupText FROM DBO.DACFollowupQuestion WHERE QID IN(
4144,
4145,
4146,
4147,
4148
) ORDER BY QID
COMMIT

--To get newly inserted record ids
--SELECT * FROM dbo.DACFollowupQuestion WHERE QID IS NULL ORDER BY 1 
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET QID = 4336, LinkedQID = 4337  WHERE FollowupQID = 406
UPDATE DBO.DACFollowupQuestion SET QID = 4336, LinkedQID = 4340  WHERE FollowupQID = 407
UPDATE DBO.DACFollowupQuestion SET QID = 4337, LinkedQID = 4338  WHERE FollowupQID = 408
UPDATE DBO.DACFollowupQuestion SET QID = 4337, LinkedQID = 4338  WHERE FollowupQID = 409
UPDATE DBO.DACFollowupQuestion SET QID = 4338, LinkedQID = 4339  WHERE FollowupQID = 410
UPDATE DBO.DACFollowupQuestion SET QID = 4338, LinkedQID = 4340  WHERE FollowupQID = 411
UPDATE DBO.DACFollowupQuestion SET QID = 4339, LinkedQID = 4340  WHERE FollowupQID = 412
UPDATE DBO.DACFollowupQuestion SET QID = 4339, LinkedQID = 4340  WHERE FollowupQID = 413
UPDATE DBO.DACFollowupQuestion SET QID = 4340, LinkedQID = NULL  WHERE FollowupQID = 414
UPDATE DBO.DACFollowupQuestion SET QID = 4340, LinkedQID = NULL  WHERE FollowupQID = 415
COMMIT

--Section II and Subsection III - folloup questions
BEGIN TRAN
INSERT INTO DBO.DACFollowupQuestion (ResponseType, FollowupText)
--C1-C5
SELECT ResponseType, FollowupText FROM dbo.DACFollowupQuestion where QID in (
4149,
4150,
4151,
4152,
4153
) ORDER BY QID
COMMIT

--To get newly inserted record ids
--SELECT * FROM dbo.DACFollowupQuestion WHERE QID IS NULL ORDER BY 1 
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET QID = 4341, LinkedQID = 4344  WHERE FollowupQID = 416
UPDATE DBO.DACFollowupQuestion SET QID = 4341, LinkedQID = 4342  WHERE FollowupQID = 417
UPDATE DBO.DACFollowupQuestion SET QID = 4342, LinkedQID = 4343  WHERE FollowupQID = 418
UPDATE DBO.DACFollowupQuestion SET QID = 4342, LinkedQID = 4343  WHERE FollowupQID = 419
UPDATE DBO.DACFollowupQuestion SET QID = 4343, LinkedQID = 4344  WHERE FollowupQID = 420
UPDATE DBO.DACFollowupQuestion SET QID = 4343, LinkedQID = 4344  WHERE FollowupQID = 421
UPDATE DBO.DACFollowupQuestion SET QID = 4344, LinkedQID = 4345  WHERE FollowupQID = 422
UPDATE DBO.DACFollowupQuestion SET QID = 4344, LinkedQID = 4345  WHERE FollowupQID = 423
UPDATE DBO.DACFollowupQuestion SET QID = 4345, LinkedQID = NULL  WHERE FollowupQID = 424
UPDATE DBO.DACFollowupQuestion SET QID = 4345, LinkedQID = NULL  WHERE FollowupQID = 425
COMMIT


--Section II and Subsection IV - folloup questions
BEGIN TRAN
INSERT INTO DBO.DACFollowupQuestion (ResponseType, FollowupText)
--D1-D14
SELECT ResponseType, FollowupText FROM dbo.DACFollowupQuestion where QID in (
4154,
4155,
4156,
4157,
4158,
4159,
4160,
4161,
4162,
4163,
4164,
4165,
4166,
4167
) ORDER BY QID
COMMIT

--To get newly inserted record ids
--SELECT * FROM dbo.DACFollowupQuestion WHERE QID IS NULL ORDER BY 1 
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET QID = 4346, LinkedQID = 4347  WHERE FollowupQID = 436
UPDATE DBO.DACFollowupQuestion SET QID = 4346, LinkedQID = 4347  WHERE FollowupQID = 437

UPDATE DBO.DACFollowupQuestion SET QID = 4347, LinkedQID = 4348  WHERE FollowupQID = 438
UPDATE DBO.DACFollowupQuestion SET QID = 4347, LinkedQID = NULL  WHERE FollowupQID = 439

UPDATE DBO.DACFollowupQuestion SET QID = 4348, LinkedQID = 4349  WHERE FollowupQID = 440
UPDATE DBO.DACFollowupQuestion SET QID = 4348, LinkedQID = 4349  WHERE FollowupQID = 441
--D5 Yes
UPDATE DBO.DACFollowupQuestion SET QID = 4349, LinkedQID = 4350  WHERE FollowupQID = 442

--D6
UPDATE DBO.DACFollowupQuestion SET QID = 4349, LinkedQID = 4351  WHERE FollowupQID = 443
UPDATE DBO.DACFollowupQuestion SET QID = 4350, LinkedQID = 4351  WHERE FollowupQID = 444
--D7
UPDATE DBO.DACFollowupQuestion SET QID = 4350, LinkedQID = 4351  WHERE FollowupQID = 445

UPDATE DBO.DACFollowupQuestion SET QID = 4351, LinkedQID = 4352  WHERE FollowupQID = 446
--D8 Link
UPDATE DBO.DACFollowupQuestion SET QID = 4351, LinkedQID = 4353  WHERE FollowupQID = 447
UPDATE DBO.DACFollowupQuestion SET QID = 4352, LinkedQID = 4353  WHERE FollowupQID = 448

UPDATE DBO.DACFollowupQuestion SET QID = 4352, LinkedQID = 4354  WHERE FollowupQID = 449
--D8 No link
--D9
UPDATE DBO.DACFollowupQuestion SET QID = 4354, LinkedQID = 4355  WHERE FollowupQID = 450
UPDATE DBO.DACFollowupQuestion SET QID = 4354, LinkedQID = 4355  WHERE FollowupQID = 451
--D10-No
UPDATE DBO.DACFollowupQuestion SET QID = 4355, LinkedQID = 4356  WHERE FollowupQID = 452
--D11
UPDATE DBO.DACFollowupQuestion SET QID = 4356, LinkedQID = 4357  WHERE FollowupQID = 453
UPDATE DBO.DACFollowupQuestion SET QID = 4356, LinkedQID = 4357  WHERE FollowupQID = 454
--D12
UPDATE DBO.DACFollowupQuestion SET QID = 4357, LinkedQID = 4358  WHERE FollowupQID = 455
UPDATE DBO.DACFollowupQuestion SET QID = 4357, LinkedQID = 4358  WHERE FollowupQID = 456
--D13
UPDATE DBO.DACFollowupQuestion SET QID = 4358, LinkedQID = NULL  WHERE FollowupQID = 457
UPDATE DBO.DACFollowupQuestion SET QID = 4358, LinkedQID = 4359  WHERE FollowupQID = 458
--D14
UPDATE DBO.DACFollowupQuestion SET QID = 4350, LinkedQID = NULL  WHERE FollowupQID = 459
COMMIT

--Section II and Subsection V - folloup questions
BEGIN TRAN
INSERT INTO DBO.DACFollowupQuestion (ResponseType, FollowupText)
--E1-E7
SELECT ResponseType, FollowupText FROM dbo.DACFollowupQuestion where QID in (
4168,
4169,
4170,
4171,
4172,
4173,
4174
) ORDER BY QID
COMMIT

--To get newly inserted record ids
--SELECT * FROM dbo.DACFollowupQuestion WHERE QID IS NULL ORDER BY 1 
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET QID = 4360, LinkedQID = 4361  WHERE FollowupQID = 460
UPDATE DBO.DACFollowupQuestion SET QID = 4360, LinkedQID = NULL  WHERE FollowupQID = 461

UPDATE DBO.DACFollowupQuestion SET QID = 4361, LinkedQID = NULL  WHERE FollowupQID = 462
UPDATE DBO.DACFollowupQuestion SET QID = 4361, LinkedQID = 4362  WHERE FollowupQID = 463

UPDATE DBO.DACFollowupQuestion SET QID = 4362, LinkedQID = NULL  WHERE FollowupQID = 464
UPDATE DBO.DACFollowupQuestion SET QID = 4362, LinkedQID = 4363  WHERE FollowupQID = 465

UPDATE DBO.DACFollowupQuestion SET QID = 4363, LinkedQID = 4364  WHERE FollowupQID = 466
UPDATE DBO.DACFollowupQuestion SET QID = 4363, LinkedQID = NULL  WHERE FollowupQID = 467

UPDATE DBO.DACFollowupQuestion SET QID = 4364, LinkedQID = NULL  WHERE FollowupQID = 468
UPDATE DBO.DACFollowupQuestion SET QID = 4364, LinkedQID = 4365  WHERE FollowupQID = 469

UPDATE DBO.DACFollowupQuestion SET QID = 4365, LinkedQID = 4366  WHERE FollowupQID = 470
UPDATE DBO.DACFollowupQuestion SET QID = 4365, LinkedQID = NULl  WHERE FollowupQID = 471

UPDATE DBO.DACFollowupQuestion SET QID = 4366, LinkedQID = NULL  WHERE FollowupQID = 472
UPDATE DBO.DACFollowupQuestion SET QID = 4366, LinkedQID = NULl  WHERE FollowupQID = 473
COMMIT


--Section II and Subsection VI - folloup questions
BEGIN TRAN
INSERT INTO DBO.DACFollowupQuestion (ResponseType, FollowupText)
--F1-F5
SELECT ResponseType, FollowupText FROM dbo.DACFollowupQuestion where QID in (
4175,
4176,
4177,
4178,
4179
) ORDER BY QID
COMMIT

--To get newly inserted record ids
--SELECT * FROM dbo.DACFollowupQuestion WHERE QID IS NULL ORDER BY 1 
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET QID = 4367, LinkedQID = 4368  WHERE FollowupQID = 474

UPDATE DBO.DACFollowupQuestion SET QID = 4368, LinkedQID = 4369  WHERE FollowupQID = 475
UPDATE DBO.DACFollowupQuestion SET QID = 4368, LinkedQID = 4371  WHERE FollowupQID = 476

UPDATE DBO.DACFollowupQuestion SET QID = 4369, LinkedQID = 4370  WHERE FollowupQID = 477
UPDATE DBO.DACFollowupQuestion SET QID = 4369, LinkedQID = 4370  WHERE FollowupQID = 478

UPDATE DBO.DACFollowupQuestion SET QID = 4370, LinkedQID = NULL  WHERE FollowupQID = 479
COMMIT


--Section III and Subsection I - folloup questions
BEGIN TRAN
INSERT INTO DBO.DACFollowupQuestion (ResponseType, FollowupText)
--A1-A3
SELECT ResponseType, FollowupText FROM dbo.DACFollowupQuestion where QID in (
4180,
4181,
4182)ORDER BY QID
COMMIT

--To get newly inserted record ids
--SELECT * FROM dbo.DACFollowupQuestion WHERE QID IS NULL ORDER BY 1 
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET QID = 4372, LinkedQID = 4373  WHERE FollowupQID = 480
UPDATE DBO.DACFollowupQuestion SET QID = 4372, LinkedQID = 4373  WHERE FollowupQID = 481
UPDATE DBO.DACFollowupQuestion SET QID = 4373, LinkedQID = 4374  WHERE FollowupQID = 482
UPDATE DBO.DACFollowupQuestion SET QID = 4373, LinkedQID = 4374  WHERE FollowupQID = 483
UPDATE DBO.DACFollowupQuestion SET QID = 4374, LinkedQID = NULL  WHERE FollowupQID = 484
UPDATE DBO.DACFollowupQuestion SET QID = 4374, LinkedQID = NULL  WHERE FollowupQID = 485
COMMIT

--Section III and Subsection II - folloup questions
BEGIN TRAN
INSERT INTO DBO.DACFollowupQuestion (ResponseType, FollowupText)
--B1
SELECT ResponseType, FollowupText FROM dbo.DACFollowupQuestion where QID in (
4183)ORDER BY QID
COMMIT

--To get newly inserted record ids
--SELECT * FROM dbo.DACFollowupQuestion WHERE QID IS NULL ORDER BY 1 
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET QID = 4375, LinkedQID = NULL  WHERE FollowupQID = 486
UPDATE DBO.DACFollowupQuestion SET QID = 4375, LinkedQID = NULL  WHERE FollowupQID = 487
COMMIT


--Section III and Subsection III - folloup questions
BEGIN TRAN
INSERT INTO DBO.DACFollowupQuestion (ResponseType, FollowupText)
--C1-C2
SELECT ResponseType, FollowupText FROM dbo.DACFollowupQuestion where QID in (
4184,
4185)
ORDER BY QID
COMMIT

--To get newly inserted record ids
--SELECT * FROM dbo.DACFollowupQuestion WHERE QID IS NULL ORDER BY 1 
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET QID = 4376, LinkedQID = 4377  WHERE FollowupQID = 488
UPDATE DBO.DACFollowupQuestion SET QID = 4376, LinkedQID = 4377  WHERE FollowupQID = 489
COMMIT


--Section III and Subsection IV - folloup questions
BEGIN TRAN
INSERT INTO DBO.DACFollowupQuestion (ResponseType, FollowupText)
--D1-D6
SELECT ResponseType, FollowupText FROM dbo.DACFollowupQuestion where QID in (
4186,
4187,
4188,
4189,
4190,
4191)
ORDER BY QID
COMMIT

--To get newly inserted record ids
--SELECT * FROM dbo.DACFollowupQuestion WHERE QID IS NULL ORDER BY 1 
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET QID = 4378, LinkedQID = 4379  WHERE FollowupQID = 490
UPDATE DBO.DACFollowupQuestion SET QID = 4378, LinkedQID = 4380  WHERE FollowupQID = 491

UPDATE DBO.DACFollowupQuestion SET QID = 4379, LinkedQID = 4380  WHERE FollowupQID = 492
UPDATE DBO.DACFollowupQuestion SET QID = 4379, LinkedQID = 4380  WHERE FollowupQID = 493


UPDATE DBO.DACFollowupQuestion SET QID = 4380, LinkedQID = 4381  WHERE FollowupQID = 494
UPDATE DBO.DACFollowupQuestion SET QID = 4380, LinkedQID = 4381  WHERE FollowupQID = 495

UPDATE DBO.DACFollowupQuestion SET QID = 4381, LinkedQID = 4382  WHERE FollowupQID = 496
UPDATE DBO.DACFollowupQuestion SET QID = 4382, LinkedQID = 4383  WHERE FollowupQID = 497
UPDATE DBO.DACFollowupQuestion SET QID = 4382, LinkedQID = 4383  WHERE FollowupQID = 498
COMMIT

--Section IV - Final IC - correction added in previous data correction .sql
--Delete duplicate sections
DELETE FROM DACQuestionBank WHERE AssetID = 4 AND ProcessGroupID = 2 AND QSecID IN (1062)
DELETE FROM DACFormMaster WHERE AssetID = 4 AND DACFormID IN (SELECT DISTINCT DACFormID FROM DACSectionAnswers WHERE QSecID = 1062)
DELETE FROM DACSectionAnswers WHERE QSecID in (1062)
DELETE FROM DACQuestionSubSection WHERE QSecID = 1062
DELETE FROM DACQuestionSections WHERE AssetID = 4 AND QSecID = 1062

--Section V and Subsection I - folloup questions

BEGIN TRAN
INSERT INTO DBO.DACFollowupQuestion (ResponseType, FollowupText)
--B1-B5
SELECT ResponseType, FollowupText FROM dbo.DACFollowupQuestion where QID in (
4227,
4228,
4229,
4230,
4231,
4232,
4233,
4234,
4235,
4236,
4237,
4238,
4239,
4240,
4241,
4242,
4243,
4244,
4245,
4246,
4247,
4248,
4249)
ORDER BY QID
COMMIT

--To get newly inserted record ids
--SELECT * FROM dbo.DACFollowupQuestion WHERE QID IS NULL ORDER BY 1 
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET QID = 4378, LinkedQID = 4379  WHERE FollowupQID = 490
UPDATE DBO.DACFollowupQuestion SET QID = 4378, LinkedQID = 4380  WHERE FollowupQID = 491

UPDATE DBO.DACFollowupQuestion SET QID = 4379, LinkedQID = 4380  WHERE FollowupQID = 492
UPDATE DBO.DACFollowupQuestion SET QID = 4379, LinkedQID = 4380  WHERE FollowupQID = 493


UPDATE DBO.DACFollowupQuestion SET QID = 4380, LinkedQID = 4381  WHERE FollowupQID = 494
UPDATE DBO.DACFollowupQuestion SET QID = 4380, LinkedQID = 4381  WHERE FollowupQID = 495

UPDATE DBO.DACFollowupQuestion SET QID = 4381, LinkedQID = 4382  WHERE FollowupQID = 496
UPDATE DBO.DACFollowupQuestion SET QID = 4382, LinkedQID = 4383  WHERE FollowupQID = 497
UPDATE DBO.DACFollowupQuestion SET QID = 4382, LinkedQID = 4383  WHERE FollowupQID = 498 
COMMIT

---------------------------------------------------------

