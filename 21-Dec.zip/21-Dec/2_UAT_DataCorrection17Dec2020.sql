SELECT * FROM DBO.DACQuestionBank WHERE QID = 4361
BEGIN TRAN
--In this section, already question group id set 1, hence this question set to null
UPDATE DBO.DACQuestionBank SET QuestionGroupID=NULL WHERE QID = 4361
COMMIT

--Section 7(2), Section 8, Section 11
SELECT * FROM DBO.DACQuestionBank WHERE QID IN(4227,4250,4268,4273,4276,4278,4284,4286,4295,4308,4310)
BEGIN TRAN
--In this section,  question group id NULL, hence this question set to 1 for first record
UPDATE DBO.DACQuestionBank SET QuestionGroupID=1 WHERE QID IN(4227,4250,4268,4273,4276,4278,4284,4286,4295,4308,4310)
COMMIT


--Section 2 - Total questions fixes

--1070	1060	B. Diversification limits - 5
--1094	1045	B. Diversification limits -5
--1126	1060	C. Geographic Limits -5
--1095	1045	C. Geographic Limits -5
--1127	1060	D. Other Investment Restrictions-14
--1096	1045	D. Other Investment Restrictions-14
--1128	1060	E. Investments during a Key Person or Change of Control Suspension-7
--1097	1045	E. Investments during a Key Person or Change of Control Suspension-7
SELECT * FROM DBO.DACQuestionSubSection WHERE SecPartID IN(1070,1094,1095)
BEGIN TRAN

UPDATE DBO.DACQuestionSubSection SET TotalQuestions=5 WHERE SecPartID IN(1070,1094,1095)
COMMIT

SELECT * FROM DBO.DACQuestionSubSection WHERE SecPartID IN(1127,1096)
BEGIN TRAN

UPDATE DBO.DACQuestionSubSection SET TotalQuestions=14 WHERE SecPartID IN(1127,1096)
COMMIT

SELECT * FROM DBO.DACQuestionSubSection WHERE SecPartID IN(1128,1097)
BEGIN TRAN

UPDATE DBO.DACQuestionSubSection SET TotalQuestions=7 WHERE SecPartID IN(1128,1097)
COMMIT

--Section 3 - Total questions
--1101	1046	C. Tax structuring paper - 2
--1100	1046	B. Results of tax due diligence -1
--1131	1061	B. Results of tax due diligence	-1
SELECT * FROM DBO.DACQuestionSubSection WHERE SecPartID IN(1100,1131, 1101)
select * FROM  DBO.DACQUESTIONbANK  where QID = 4183
BEGIN TRAN
UPDATE DBO.DACQuestionSubSection SET TotalQuestions=1 WHERE  SecPartID IN(1100,1131)
UPDATE DBO.DACQuestionSubSection SET TotalQuestions=2 WHERE  SecPartID IN(1101)

UPDATE DBO.DACQUESTIONbANK SET QUestionGroupId =1 where QID = 4183
COMMIT

--Section 6(1)
--1105	1049	B. Excused Investors - 23

SELECT * FROM DBO.DACQuestionSubSection WHERE SecPartID IN(1105)
BEGIN TRAN
UPDATE DBO.DACQuestionSubSection SET TotalQuestions=23 WHERE  SecPartID IN(1105)
COMMIT

--Section 7(2) - Leagal - Total questions


--1110	1053	B. Listed securities / price-sensitive information - 1
--1111	1053	C. Investment documentation - 1
--1115	1053	G. Information - 1
--1118	1053	J. Pre-Final IC -1

--1113	1053	E. Engagement of consultants / advisors - 3

--1114	1053	F. Non-compete / restrictive covenants database - 2
--1117	1053	I. Other -2
--1119	1053	K. Post-Final IC and prior to legal commitment -2

SELECT * FROM DBO.DACQuestionSubSection WHERE SecPartID IN(1110,1111,1113,1114,1115,1117,1118,1119)
BEGIN TRAN
--1
UPDATE DBO.DACQuestionSubSection SET TotalQuestions= 1 WHERE SecPartID IN(1110,1111,1115,1118)
--2
UPDATE DBO.DACQuestionSubSection SET TotalQuestions= 2 WHERE SecPartID IN( 1114,1117,1119)
--3
UPDATE DBO.DACQuestionSubSection SET TotalQuestions= 3 WHERE SecPartID = 1113
COMMIT


--Section 8 - VIII Responsible Investment

--Total no. of question is wrong. it is 1 insted 2
SELECT * FROM DBO.DACQuestionSubSection WHERE SecPartID IN (1121,1152)
SELECT * FROM DBO.DACQuestionSubSection WHERE SecPartID IN (1120,1151)
BEGIN TRAN

UPDATE DBO.DACQuestionSubSection SET TotalQuestions=2 WHERE SecPartID IN( 1121, 1152)

UPDATE DBO.DACQuestionSubSection SET TotalQuestions=6 WHERE SecPartID IN (1120,1151)
COMMIT

--section 11
--1058 - A. Conflicts of interest - 2
--1059 - B. Related Party Transactions - 2
--1060 - C. Personal interests - 1
--1061 - D. Conflicts of interest - 1
SELECT * FROM DBO.DACQuestionSubSection WHERE SecPartID IN( 1058,1059,1060,1061)
BEGIN TRAN
--2
UPDATE DBO.DACQuestionSubSection SET TotalQuestions=2 WHERE SecPartID IN( 1058,1059)
--1
UPDATE DBO.DACQuestionSubSection SET TotalQuestions=1 WHERE  SecPartID IN( 1060,1061)
COMMIT

--Section 12
--1058	A. Customer DD-3
SELECT * FROM DBO.DACQuestionSubSection WHERE SecPartID IN(1062)
BEGIN TRAN

UPDATE DBO.DACQuestionSubSection SET TotalQuestions=3 WHERE  SecPartID IN(1062)
COMMIT


---18/12/2020  - 11.46PM
select * from dbo.DACFollowupQuestion where qid = 4182
update  dbo.DACFollowupQuestion set LinkedQID = NULL where qid = 4182

--Testing Sheet - Issue 32
select * from dbo.DACQuestionBank where QID in (
4131,
4132,
4133,
4134,
4135,
4136)
select * from dbo.DACFollowupQuestion where qid in(
4131,
4132,
4133,
4134,
4135,
4136)

--Set NULL for circular reference linked question records
SELECT * FROM DBO.DACFollowupQuestion WHERE QID IN (4136)
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET LinkedQID = NULL WHERE QID IN (4136)
COMMIT

SELECT * FROM DBO.DACFollowupQuestion WHERE FollowupQID =28
SELECT * FROM DBO.DACFollowupQuestion WHERE FollowupQID =27
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET ResponseType = 1, LinkedQID = NULL WHERE FollowupQID =28
UPDATE DBO.DACFollowupQuestion SET ResponseType = 0 WHERE FollowupQID =27
COMMIT

--Section I - A1-A7 and B1-B6 data correction
SELECT * FROM DBO.DACFollowupQuestion WHERE FollowupQID IN(17, 18, 29,30)
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET LinkedQID = NULL WHERE FollowupQID IN(17, 18, 29,30)
COMMIT

--Section II 
--B1 - B6
SELECT * FROM DBO.DACFollowupQuestion WHERE FollowupQID IN(53,54)
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET LinkedQID = NULL WHERE FollowupQID IN(53,54)
COMMIT

--D1-D14
SELECT * FROM DBO.DACQuestionBank WHERE QID = 4166
SELECT * FROM DBO.DACFollowupQuestion WHERE FollowupQID = 216
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET LinkedQID = NULL WHERE FollowupQID = 216
COMMIT

--F1-F7
SELECT * FROM DBO.DACFollowupQuestion WHERE FollowupQID IN (85,
86,
87,
88,
89,
223)
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET LinkedQID = NULL WHERE FollowupQID IN (85,
86,
87,
88,
89,
223)
COMMIT

--Section III
--TODO

--Section 4 - Taxes for Actis Tax team
--Correct Section Name
--Correct Sub section name
--Correct total questions
select * from dbo.DACQuestionSections where QSecID in( 1066)
select * from dbo.DACQuestionSubSection where SecPartID = 1138
BEGIN TRAN
UPDATE DBO.DACQuestionSections SET SectionName='SECTION IV', SectionHeading='SECTION IV - Tax for Actis Tax Team' WHERE  QSecID =1066
UPDATE dbo.DACQuestionSubSection SET SubSecName ='A. Other considerations ', SubSecHeadingText ='A. Other considerations', TotalQuestions = 12  WHERE SecPartID =1138
COMMIT 

--Correct questions, sectoin v(3) leverage questions added to section iv
BEGIN TRAN
UPDATE DBO.DACQuestionBank SET QuestionText = (SELECT QuestionText FROM DBO.DACQuestionBank WHERE QID = 4192), QuestionGroupID = 1 WHERE QID = 4449
UPDATE DBO.DACQuestionBank SET QuestionText = (SELECT QuestionText FROM DBO.DACQuestionBank WHERE QID = 4193) WHERE QID = 4450
UPDATE DBO.DACQuestionBank SET QuestionText = (SELECT QuestionText FROM DBO.DACQuestionBank WHERE QID = 4194) WHERE QID = 4451
UPDATE DBO.DACQuestionBank SET QuestionText = (SELECT QuestionText FROM DBO.DACQuestionBank WHERE QID = 4195) WHERE QID = 4452
UPDATE DBO.DACQuestionBank SET QuestionText = (SELECT QuestionText FROM DBO.DACQuestionBank WHERE QID = 4196) WHERE QID = 4453
UPDATE DBO.DACQuestionBank SET QuestionText = (SELECT QuestionText FROM DBO.DACQuestionBank WHERE QID = 4197) WHERE QID = 4454
UPDATE DBO.DACQuestionBank SET QuestionText = (SELECT QuestionText FROM DBO.DACQuestionBank WHERE QID = 4198) WHERE QID = 4455
UPDATE DBO.DACQuestionBank SET QuestionText = (SELECT QuestionText FROM DBO.DACQuestionBank WHERE QID = 4199) WHERE QID = 4456
UPDATE DBO.DACQuestionBank SET QuestionText = (SELECT QuestionText FROM DBO.DACQuestionBank WHERE QID = 4200) WHERE QID = 4457

INSERT INTO DBO.DACQuestionBank
	  SELECT [QusetionNo],[QuestionText],[DisplayOrder],[IsQuestionHeading],[IsActive],[IsCompulsory],[IsSubQuestion],[ParentQID]
      ,[AssetID],1066 AS [QSecID] ,1138 [SecPartID],[QuestionGroupID],[PreIC_QID],[IsLpSpecific],[LP],[Metric],[ClauseReference],2 AS [ProcessGroupID] FROM DBO.DACQuestionBank WHERE QID = 4201

INSERT INTO DBO.DACQuestionBank SELECT [QusetionNo],[QuestionText],[DisplayOrder],[IsQuestionHeading],[IsActive],[IsCompulsory],[IsSubQuestion],[ParentQID]
      ,[AssetID],1066 AS [QSecID] ,1138 [SecPartID],[QuestionGroupID],[PreIC_QID],[IsLpSpecific],[LP],[Metric],[ClauseReference],2 AS [ProcessGroupID] FROM DBO.DACQuestionBank WHERE QID = 4202

INSERT INTO DBO.DACQuestionBank SELECT [QusetionNo],[QuestionText],[DisplayOrder],[IsQuestionHeading],[IsActive],[IsCompulsory],[IsSubQuestion],[ParentQID]
      ,[AssetID], 1066 AS [QSecID] ,1138 [SecPartID],[QuestionGroupID],[PreIC_QID],[IsLpSpecific],[LP],[Metric],[ClauseReference],2 AS [ProcessGroupID] FROM DBO.DACQuestionBank WHERE QID = 4203 
COMMIT


--Insert linked questions
BEGIN TRAN
INSERT INTO DBO.DACFollowupQuestion (ResponseType, FollowupText)
SELECT ResponseType, FollowupText FROM DBO.DACFollowupQuestion WHERE QID IN(
4192,
4193,
4194,
4195,
4196,
4197,
4198,
4199,
4200,
4201,
4202,
4203
)
COMMIT
--Update linked question IDs for above inserted records. 
--Note: Auto generated ID may change based environment
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET QID = 4449, LinkedQID = 4450  WHERE FollowupQID = 349
UPDATE DBO.DACFollowupQuestion SET QID = 4450, LinkedQID = 4451  WHERE FollowupQID = 350
UPDATE DBO.DACFollowupQuestion SET QID = 4452, LinkedQID = 4453  WHERE FollowupQID = 351
UPDATE DBO.DACFollowupQuestion SET QID = 4453, LinkedQID = 4454  WHERE FollowupQID = 352
UPDATE DBO.DACFollowupQuestion SET QID = 4454, LinkedQID = 4455  WHERE FollowupQID = 353
UPDATE DBO.DACFollowupQuestion SET QID = 4455, LinkedQID = 4456  WHERE FollowupQID = 354
UPDATE DBO.DACFollowupQuestion SET QID = 4456, LinkedQID = 4457  WHERE FollowupQID = 355
UPDATE DBO.DACFollowupQuestion SET QID = 4457, LinkedQID = 4539  WHERE FollowupQID = 356
UPDATE DBO.DACFollowupQuestion SET QID = 4539, LinkedQID = 4540  WHERE FollowupQID = 357

UPDATE DBO.DACFollowupQuestion SET QID = 4449, LinkedQID = 4450  WHERE FollowupQID = 358
UPDATE DBO.DACFollowupQuestion SET QID = 4450, LinkedQID = 4451  WHERE FollowupQID = 359
UPDATE DBO.DACFollowupQuestion SET QID = 4451, LinkedQID = 4452  WHERE FollowupQID = 360
UPDATE DBO.DACFollowupQuestion SET QID = 4452, LinkedQID = 4453  WHERE FollowupQID = 361
UPDATE DBO.DACFollowupQuestion SET QID = 4453, LinkedQID = 4454  WHERE FollowupQID = 362
UPDATE DBO.DACFollowupQuestion SET QID = 4454, LinkedQID = 4455  WHERE FollowupQID = 363
UPDATE DBO.DACFollowupQuestion SET QID = 4455, LinkedQID = 4456  WHERE FollowupQID = 364
UPDATE DBO.DACFollowupQuestion SET QID = 4456, LinkedQID = 4457  WHERE FollowupQID = 365
UPDATE DBO.DACFollowupQuestion SET QID = 4457, LinkedQID = 4539  WHERE FollowupQID = 366
UPDATE DBO.DACFollowupQuestion SET QID = 4539, LinkedQID = NULL  WHERE FollowupQID = 367
COMMIT

--Section 5 - Co-Investment - Circular ref.
select * from dbo.DACQuestionBank where qid = 4227
SELECT * FROM DBO.DACFollowupQuestion WHERE FollowupQID IN(134,267)
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET LinkedQID = NULL WHERE FollowupQID IN(134,267)
COMMIT


--Section 6(1)  - Excused investors
--155	4249	1	proceed to C1.	4250
--290	4249	0	consult with Funds Admin regarding required adjustments to the allocations � 
--please refer to cl. 4.4.10 of the LPAs in this respect, and please note that cl. 4.1.4 allows 
--for the excused portion of an investment to be drawn down from the non-excused ALLIF investors, 
--up to 30% of the amount originally called from the ALLIF investors, however in such circumstances Actis sho
--uld make sure that such additional drawdowns do not exceed any ownership restrictions agreed with such investors in the
--ir side letters). Subsequently, proceed to C1.	4250

select * from dbo.DACQuestionBank where qid = 4250
SELECT * FROM DBO.DACFollowupQuestion WHERE FollowupQID IN(155,290)
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET LinkedQID = NULL WHERE FollowupQID IN(155,290)
COMMIT

--Section 6(3) - Leverage
--Linked id 4268 referred to Section 7(2) - Legal
select * from dbo.DACQuestionSubSection where SecPartID = 1110
select * from dbo.DACQuestionBank where qid = 4268
SELECT * FROM DBO.DACFollowupQuestion WHERE LinkedQID = 4268
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET LinkedQID = NULL WHERE LinkedQID = 4268
COMMIT

--Section VI(3) - Leverage A6
select * from dbo.DACFollowupQuestion where qid = 4261
SELECT * FROM DBO.DACFollowupQuestion WHERE FollowupQID IN(300)
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET LinkedQID = NULL WHERE FollowupQID IN(300)
COMMIT


--section 7(2) - legal
--C,--D
SELECT * FROM DBO.DACFollowupQuestion WHERE FollowupQID IN(173,308,176,311,315,181,183,
184,
316,
318,
320,
186,
319,
187,
322
)
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET LinkedQID = NULL WHERE FollowupQID IN(173,308,176,311,315,181,183,
184,
316,
318,
320,
186,
319,
187,
322
)
COMMIT


--Section 8
SELECT * FROM DBO.DACFollowupQuestion WHERE FollowupQID IN(195,330)
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET LinkedQID = NULL WHERE FollowupQID IN(195,330)
COMMIT

--Section 11
SELECT * FROM DBO.DACFollowupQuestion WHERE FollowupQID IN(206,
340,
341,
208,
343
)
BEGIN TRAN
UPDATE DBO.DACFollowupQuestion SET LinkedQID = NULL WHERE FollowupQID IN(206,
340,
341,
208,
343
)
COMMIT
