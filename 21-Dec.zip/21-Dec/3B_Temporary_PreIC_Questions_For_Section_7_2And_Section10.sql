--Section 6(1) -- B2 missing for Pre IC
SET IDENTITY_INSERT DacQuestionBank ON
DECLARE @Qid BIGINT

BEGIN TRAN
SET IDENTITY_INSERT DacQuestionBank ON

SELECT @Qid = MAX(QID)+1 FROM DACQuestionBank

INSERT INTO dbo.DACQuestionBank  (QID,
[QusetionNo],[QuestionText],[DisplayOrder],[IsQuestionHeading],[IsActive],[IsCompulsory],[IsSubQuestion]
,[ParentQID],[AssetID],  QSecId,  [SecPartID],[QuestionGroupID],[PreIC_QID],[IsLpSpecific],[LP],[Metric]
,[ClauseReference], ProcessGroupID
)
SELECT @Qid, [QusetionNo],[QuestionText],[DisplayOrder],[IsQuestionHeading],[IsActive],[IsCompulsory],[IsSubQuestion]
,[ParentQID],[AssetID], 1049 AS QSecId, 1105 AS SecPartID,[QuestionGroupID],[PreIC_QID],[IsLpSpecific],[LP],[Metric]
,[ClauseReference],1 AS ProcessGroupID
FROM dbo.DACQuestionBank WHERE qid = 4420

SET IDENTITY_INSERT DacQuestionBank OFF
COMMIT


--Section VII (2) -- Pre-IC question missing
BEGIN TRAN
INSERT INTO DBO.DACQuestionSubSection ( QSecID, SubSecName, SubSecHeadingText, TotalQuestions)
SELECT 1052 AS QSecID, SubSecName, SubSecHeadingText, TotalQuestions
FROM dbo.DACQuestionSubSection WHERE SecPartID = 1139

DECLARE @New_SecPartID BIGINT
SET @New_SecPartID = @@IDENTITY
--SELECT * FROM DBO.DACQuestionSubSection WHERE SecPartID = @@IDENTITY
INSERT INTO dbo.DACQuestionBank  (
[QusetionNo],[QuestionText],[DisplayOrder],[IsQuestionHeading],[IsActive],[IsCompulsory],[IsSubQuestion]
,[ParentQID],[AssetID],  QSecId,  [SecPartID],[QuestionGroupID],[PreIC_QID],[IsLpSpecific],[LP],[Metric]
,[ClauseReference], ProcessGroupID
)
SELECT  [QusetionNo],[QuestionText],[DisplayOrder],[IsQuestionHeading],[IsActive],[IsCompulsory],[IsSubQuestion]
,[ParentQID],[AssetID], 1052 AS QSecId, @New_SecPartID AS SecPartID,[QuestionGroupID],[PreIC_QID],[IsLpSpecific],[LP],[Metric]
,[ClauseReference],1 AS ProcessGroupID
FROM DBO.DACQuestionBank WHERE QSecID = 1067 and SecPartID = 1139
COMMIT


--Section VII (2) -- Pre-IC question missing
BEGIN TRAN
INSERT INTO DBO.DACQuestionSubSection ( QSecID, SubSecName, SubSecHeadingText, TotalQuestions)
SELECT 1052 AS QSecID, SubSecName, SubSecHeadingText, TotalQuestions
FROM dbo.DACQuestionSubSection WHERE SecPartID = 1139

DECLARE @New_SecPartID BIGINT
SET @New_SecPartID = @@IDENTITY
--SELECT * FROM DBO.DACQuestionSubSection WHERE SecPartID = @@IDENTITY
INSERT INTO dbo.DACQuestionBank  (
[QusetionNo],[QuestionText],[DisplayOrder],[IsQuestionHeading],[IsActive],[IsCompulsory],[IsSubQuestion]
,[ParentQID],[AssetID],  QSecId,  [SecPartID],[QuestionGroupID],[PreIC_QID],[IsLpSpecific],[LP],[Metric]
,[ClauseReference], ProcessGroupID
)
SELECT  [QusetionNo],[QuestionText],[DisplayOrder],[IsQuestionHeading],[IsActive],[IsCompulsory],[IsSubQuestion]
,[ParentQID],[AssetID], 1052 AS QSecId, @New_SecPartID AS SecPartID,[QuestionGroupID],[PreIC_QID],[IsLpSpecific],[LP],[Metric]
,[ClauseReference],1 AS ProcessGroupID
FROM DBO.DACQuestionBank WHERE QSecID = 1067 and SecPartID = 1139
COMMIT



---Section 10
BEGIN TRAN
INSERT INTO dbo.DACQuestionBank  (
[QusetionNo],[QuestionText],[DisplayOrder],[IsQuestionHeading],[IsActive],[IsCompulsory],[IsSubQuestion]
,[ParentQID],[AssetID],  QSecId,  [SecPartID],[QuestionGroupID],[PreIC_QID],[IsLpSpecific],[LP],[Metric]
,[ClauseReference], ProcessGroupID
)
SELECT  [QusetionNo],[QuestionText],[DisplayOrder],[IsQuestionHeading],[IsActive],[IsCompulsory],[IsSubQuestion]
,[ParentQID],[AssetID], 1056 AS QSecId, 1123 AS SecPartID,[QuestionGroupID],[PreIC_QID],[IsLpSpecific],[LP],[Metric]
,[ClauseReference],1 AS ProcessGroupID
FROM DBO.DACQuestionBank WHERE QSecID = 1071 and SecPartID = 1154
COMMIT

