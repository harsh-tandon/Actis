
select QS.QSecID, QS.SectionName,QS.SectionHeading, QSS.SecPartID, QSS.SubSecName, QSS.SubSecHeadingText, QB.QID, QB.QusetionNo, QB.QuestionText,FQ.ResponseType, FQ.FollowupText,FQ.LinkedQID from dbo.DACQuestionBank QB
inner join dbo.DACQuestionSections QS  ON QB.QSecID = QS.QSecID
inner join dbo.DACQuestionSubSection QSS ON QSS.SecPartID = QB.SecPartID
left join dbo.DACFollowupQuestion FQ ON QB.QID = FQ.QID
WHERE QB.QID = 4153

--Link QID
select * from dbo.DACQuestionBank where qid = 4159
select * from dbo.DACFollowupQuestion where qid = 4158
--Search by QuestionID
select QS.QSecID, QS.SectionName, QSS.SecPartID, QSS.SubSecName,QB.QID, QB.QusetionNo,  QB.QuestionText, QB.Metric, FQ.ResponseType, FQ.FollowupText,FQ.LinkedQID from dbo.DACQuestionBank QB
inner join dbo.DACQuestionSections QS  ON QB.QSecID = QS.QSecID
inner join dbo.DACQuestionSubSection QSS ON QSS.SecPartID = QB.SecPartID
left join dbo.DACFollowupQuestion FQ ON QB.QID = FQ.QID
WHERE QB.QusetionNo = 'E1'
SELECT * FROM DBO.DACQuestionSubSection WHERE SubSecHeadingText LIKE '%letter%'

--Check Question GroupID and Sub-Section Total Questions
select * from dbo.DACQuestionSections where  AssetID = 4
--Section I
select * from dbo.DACQuestionSubSection where QSecID IN( 1044, 1059)
SELECT * FROM DBO.DACQuestionBank WHERE QSecID IN( 1044, 1059) and SecPartID in(1124,
1125,
1068,1090,1091,1092)

--Section 1 - A1 - A7

select * from dbo.DACFollowupQuestion where QID in (
4124,
4125,
4126,
4127,
4128,
4129,
4130
)
--B1-B6
select * from dbo.DACFollowupQuestion where QID in (
4131,
4132,
4133,
4134,
4135,
4136
)

--C1
select * from dbo.DACFollowupQuestion where qid = 4329

--Final IC  -- No Linked Qids
--A1-A7
select * from dbo.DACFollowupQuestion where QID in (
4316,
4317,
4318,
4319,
4320,
4321,
4322
)

select * from dbo.DACFollowupQuestion where QID in (
4323,
4324,
4325,
4326,
4327,
4328
)

select * from dbo.DACFollowupQuestion where QID in (
4329
)
--Section 2
select * from dbo.DACQuestionSubSection where QSecID in( 1045,1060)
SELECT * FROM DBO.DACQuestionBank WHERE QSecID in( 1045, 1060 ) and SecPartID in(1096)
select * from dbo.DACFollowupQuestion where qid in (
4154,
4155,
4156,
4157,
4158,
4159,
4160,
4161,
4162,
4163,
4164,
4165,
4166,
4167
)

SELECT * FROM DBO.DACQuestionBank WHERE QSecID in( 1045, 1060 ) and SecPartID in(1126,
1127,
1128,
1069,
1070,
1093,
1094,
1095,
1096,
1097,
1098,
1129)

--A1 - A6
select * from dbo.DACFollowupQuestion where QID in (
4138,
4139,
4140,
4141,
4142,
4143
)

--B1-B5
select * from dbo.DACFollowupQuestion where QID in (
4144,
4145,
4146,
4147,
4148
)

--C1-C5
select * from dbo.DACFollowupQuestion where QID in (
4149,
4150,
4151,
4152,
4153
)

--D1-D14
select * from dbo.DACFollowupQuestion where QID in (
4154,
4155,
4156,
4157,
4158,
4159,
4160,
4161,
4162,
4163,
4164,
4165,
4166,
4167
)

--E1-E7
select * from dbo.DACFollowupQuestion where QID in (
4168,
4169,
4170,
4171,
4172,
4173,
4174
)

--F1--F5
select * from dbo.DACFollowupQuestion where QID in (
4175,
4176,
4177,
4178,
4179
)

--Final IC 
--A1-A6
select * from dbo.DACFollowupQuestion where QID in (
4330,
4331,
4332,
4333,
4334,
4335
)

--B1-B5
select * from dbo.DACFollowupQuestion where QID in (
4336,
4337,
4338,
4339,
4340
)

--C1-C5
select * from dbo.DACFollowupQuestion where QID in (
4341,
4342,
4343,
4344,
4345
)

--D1-D14
select * from dbo.DACFollowupQuestion where QID in (
4346,
4347,
4348,
4349,
4350,
4351,
4352,
4353,
4354,
4355,
4356,
4357,
4358,
4359

)

--E1-E7
select * from dbo.DACFollowupQuestion where QID in (
4360,
4361,
4362,
4363,
4364,
4365,
4366
)

--F1-F5
select * from dbo.DACFollowupQuestion where QID in (
4367,
4368,
4369,
4370,
4371
)
--
--1070	1060	B. Diversification limits - 5
--1094	1045	B. Diversification limits -5
--1126	1060	C. Geographic Limits-5
--1095	1045	C. Geographic Limits -5
--1127	1060	D. Other Investment Restrictions-14
--1096	1045	D. Other Investment Restrictions-14
--1128	1060	E. Investments during a Key Person or Change of Control Suspension-7
--1097	1045	E. Investments during a Key Person or Change of Control Suspension-7


--SECTION 3
select * from dbo.DACQuestionSections where QSecID in( 1046,1061)
select * from dbo.DACQuestionSubSection where QSecID in( 1046,1061)
SELECT * FROM DBO.DACQuestionBank WHERE QSecID in( 1046,1061) and SecPartID in(1099,
1100,
1101,
1102,
1130,
1131,
1132,
1133)

--A1-A3
SELECT * FROM DBO.DACFollowupQuestion WHERE QID IN(
4180,
4181,
4182)

--B1
SELECT * FROM DBO.DACFollowupQuestion WHERE QID IN(
4183)

--C1-C2
select * from dbo.DACQuestionBank where qid = 4185
SELECT * FROM DBO.DACFollowupQuestion WHERE QID IN(
4184,
4185)

--D1-D6
SELECT * FROM DBO.DACFollowupQuestion WHERE QID IN(
4186,
4187,
4188,
4189,
4190,
4191)

--Final IC  -- No linked qids
--A1-A3
SELECT * FROM DBO.DACFollowupQuestion WHERE QID IN(
4372,
4373,
4374
)

--B1
SELECT * FROM DBO.DACFollowupQuestion WHERE QID IN(
4375
)

--C1-C2
SELECT * FROM DBO.DACFollowupQuestion WHERE QID IN(
4376,
4377

)


--D1-D6
SELECT * FROM DBO.DACFollowupQuestion WHERE QID IN(
4378,
4379,
4380,
4381,
4382,
4383
)

--1101	1046	C. Tax structuring paper - 2
--1100	1046	B. Results of tax due diligence -1
--1131	1061	B. Results of tax due diligence	B. Results of tax due diligence -1
select * from dbo.DACQuestionSections where  AssetID = 4


--SECTION 4
select * from dbo.DACQuestionSections where QSecID in( 1047,1066)
select * from dbo.DACQuestionSubSection where QSecID in( 1047,1066)
SELECT * FROM DBO.DACQuestionBank WHERE QSecID in( 1047,1066) and SecPartID in(1103,1138)
--A - Leverage is not exist in excel
SELECT * FROM DBO.DACFollowupQuestion WHERE QID IN(
4192,
4193,
4194,
4195,
4196,
4197,
4198,
4199,
4200,
4201,
4202,
4203
)

--Final IC follow 
SELECT * FROM DBO.DACFollowupQuestion WHERE QID IN(
4449,
4450,
4451,
4452,
4453,
4454,
4455,
4456,
4457,
4539,
4540,
4541
)

--349	NULL	1	refer to General Counsel.  Subsequently proceed to A2.
--350	NULL	1	refer to MRLO. Subsequently proceed to A3.
--351	NULL	1	proceed to A5.
--352	NULL	1	Actis may need to provide information to enable investors to make a QEF election (and comply with annual reporting requirements pertaining to such QEF election) to certain investors pursuant to LPAs cl. 6.4.1(b) if investors have made a request to that effect. No requests have been made to date, but a request may be made if PFIC is generated. consider whether any investors have made such requests and subsequently proceed to A6.
--353	NULL	1	Actis must use reasonable endeavours to avoid ALLIF LP making an investment that would be a PTST. Consult with IDG Lawyer. If ALLIF LP does make an investment that would be a PTST to which Texas ERS would be treated as being a party, please note that Actis is obliged to promptly notify Texas ERS. Subsequently proceed to A7.
--354	NULL	1	Actis is under an absolute obligation to avoid knowingly engaging in a �listed transaction� in which Texas ERS would be treated as �participating in�. The agreement with SC on this point is softer as it does not have an explicit confirmation by Actis to not engage in such transaction, but just a confirmation of an intention not to. If ALLIF LP does make an investment that would be a �listed transaction� to which Texas ERS would be treated as �participating in�, Actis is obliged to promptly notify Texas ERS. No such notification obligation exists in relation to SC. Consult with IDG Lawyer and subsequently proceed to A8.
--355	NULL	1	in respect of Texas ERS, please note that Actis has confirmed to Texas TRS that it does not intend to engage in such �prohibited reportable transactions�. If ALLIF LP does engage in a �a �reportable transaction� (as defined in Regulation Section 1.6011-4(b)(2)) of the Code), Actis is obliged to promptly notify Texas ERS. If yes in respect of SC, consult with IDG Lawyer and SC will need to be notified promptly upon Actis determining that ALLIF is or has engaged in such transaction. Subsequently proceed to A9.
--356	NULL	1	Actis is obliged to promptly notify Texas ERS. Subsequently proceed to A10.
--357	NULL	1	proceed to A11.
--358	NULL	0	Proceed to A2.
--359	NULL	0	proceed to A3.
--360	NULL	0	proceed to D4.
--361	NULL	0	ensure you make the election. Subsequently proceed to A5.
--362	NULL	0	Proceed to D6.
--363	NULL	0	proceed to A7.
--364	NULL	0	proceed to A8.
--365	NULL	0	proceed to A9.
--366	NULL	0	proceed to A10.
--367	NULL	0	proceed to A12.

--4192	1	refer to General Counsel.  Subsequently proceed to A2.	4193
--4193	1	refer to MRLO. Subsequently proceed to A3.	4194
--4195	1	proceed to A5.	4196
--4196	1	Actis may need to provide information to enable investors to make a QEF election (and comply with annual reporting requirements pertaining to such QEF election) to certain investors pursuant to LPAs cl. 6.4.1(b) if investors have made a request to that effect. No requests have been made to date, but a request may be made if PFIC is generated. consider whether any investors have made such requests and subsequently proceed to A6.	4197
--4197	1	Actis must use reasonable endeavours to avoid ALLIF LP making an investment that would be a PTST. Consult with IDG Lawyer. If ALLIF LP does make an investment that would be a PTST to which Texas ERS would be treated as being a party, please note that Actis is obliged to promptly notify Texas ERS. Subsequently proceed to A7.	4198
--4198	1	Actis is under an absolute obligation to avoid knowingly engaging in a �listed transaction� in which Texas ERS would be treated as �participating in�. The agreement with SC on this point is softer as it does not have an explicit confirmation by Actis to not engage in such transaction, but just a confirmation of an intention not to. If ALLIF LP does make an investment that would be a �listed transaction� to which Texas ERS would be treated as �participating in�, Actis is obliged to promptly notify Texas ERS. No such notification obligation exists in relation to SC. Consult with IDG Lawyer and subsequently proceed to A8.	4199
--4199	1	in respect of Texas ERS, please note that Actis has confirmed to Texas TRS that it does not intend to engage in such �prohibited reportable transactions�. If ALLIF LP does engage in a �a �reportable transaction� (as defined in Regulation Section 1.6011-4(b)(2)) of the Code), Actis is obliged to promptly notify Texas ERS. If yes in respect of SC, consult with IDG Lawyer and SC will need to be notified promptly upon Actis determining that ALLIF is or has engaged in such transaction. Subsequently proceed to A9.	4200
--4200	1	Actis is obliged to promptly notify Texas ERS. Subsequently proceed to A10.	4201
--4201	1	proceed to A11.	4202

--4192	0	Proceed to A2.	4193
--4193	0	proceed to A3.	4194
--4194	0	proceed to D4.	4195
--4195	0	ensure you make the election. Subsequently proceed to A5.	4196
--4196	0	Proceed to D6.	4197
--4197	0	proceed to A7.	4198
--4198	0	proceed to A8.	4199
--4199	0	proceed to A9.	4200
--4200	0	proceed to A10.	4201
--4202	0	proceed to A12.	4203

--Section 5 - Co-Investment
select * from dbo.DACQuestionSubSection where QSecID in( 1048,1064)
SELECT * FROM DBO.DACQuestionBank WHERE QSecID in( 1048,1064) and SecPartID in(1104,
1136)

select * from dbo.DACFollowupQuestion where QID in (
4204,
4205,
4206,
4207,
4208,
4209,
4210,
4211,
4212,
4213,
4214,
4215,
4216,
4217,
4218,
4219,
4220,
4221,
4222,
4223,
4224,
4225,
4226
)

--No link question ids
select * from dbo.DACFollowupQuestion where QID in (
4419,
4420,
4421,
4422,
4423,
4424,
4425,
4426,
4427,
4428,
4429,
4430,
4431,
4432,
4433,
4434,
4435,
4436,
4437,
4438,
4439,
4440,
4441,
4442)

--A1 - Sub section and A1 -A23 -Question No & questions not added for Final IC  - moved separate sections
--B1 - Sub section and B1 - B24 -Question No & questions not added  for Pre Ic - moved separate sections


--Section 6(1) - Excused investors
select * from dbo.DACQuestionSubSection where QSecID in( 1049,1064)
SELECT * FROM DBO.DACQuestionBank WHERE QSecID in( 1049,1064) and SecPartID in(1105,
1136)
--1105	1049	B. Excused Investors - 23
--B2 QUestion not exist -- need to add for pre-IC

--155	4249	1	proceed to C1.	4250
--290	4249	0	consult with Funds Admin regarding required adjustments to the allocations � please refer to cl. 4.4.10 of the LPAs in this respect, and please note that cl. 4.1.4 allows for the excused portion of an investment to be drawn down from the non-excused ALLIF investors, up to 30% of the amount originally called from the ALLIF investors, however in such circumstances Actis should make sure that such additional drawdowns do not exceed any ownership restrictions agreed with such investors in their side letters). Subsequently, proceed to C1.	4250
select * from dbo.DACFollowupQuestion where qid in (
4227,
4228,
4229,
4230,
4231,
4232,
4233,
4234,
4235,
4236,
4237,
4238,
4239,
4240,
4241,
4242,
4243,
4244,
4245,
4246,
4247,
4248,
4249
)

--Final IC - No Linked qids
select * from dbo.DACFollowupQuestion where qid in (
4419,
4420,
4421,
4422,
4423,
4424,
4425,
4426,
4427,
4428,
4429,
4430,
4431,
4432,
4433,
4434,
4435,
4436,
4437,
4438,
4439,
4440,
4441,
4442
)

--Section 6(2) - AIV/SI
select * from dbo.DACQuestionSubSection where QSecID in( 1050,1065)
SELECT * FROM DBO.DACQuestionBank WHERE QSecID in( 1050,1065) and SecPartID in(1106,
1137)

select * from dbo.DACFollowupQuestion where qid in (
4250,
4251,
4252,
4253,
4254,
4255
)

--Final IC - No linked qids
select * from dbo.DACFollowupQuestion where qid in (
4443,
4444,
4445,
4446,
4447,
4448
)

--Section 6(3) - Leverage
select * from dbo.DACQuestionSubSection where QSecID in( 1051,1066)
SELECT * FROM DBO.DACQuestionBank WHERE QSecID in(1051,1066) and SecPartID in(1107,
1138)

select * from dbo.DACFollowupQuestion where qid in (
4256,
4257,
4258,
4259,
4260,
4261,
4262,
4263,
4264
)

select * from dbo.DACFollowupQuestion where qid in (
4449,
4450,
4451,
4452,
4453,
4454,
4455,
4456,
4457,
4539,
4540,
4541
)

--Leverage A6
select * from dbo.DACFollowupQuestion where qid = 4261


--Section 7(1) - Headging & FX
select * from dbo.DACQuestionSubSection where QSecID in( 1052,1067)
SELECT * FROM DBO.DACQuestionBank WHERE QSecID in( 1052,1067) and SecPartID in(1139)

--No Pre ic in excel file

--Final IC - No follow qids - need
select * from dbo.DACFollowupQuestion where qid in (
4458,
4459,
4460,
4461,
4462,
4463,
4464,
4465,
4466,
4467,
4468,
4469,
4470,
4471
)

--Section 7(2) - Leagal
select * from dbo.DACQuestionSubSection where QSecID in( 1053,1068)
SELECT * FROM DBO.DACQuestionBank WHERE QSecID in( 1053,1068) and SecPartID in(1109,
1110,
1111,
1112,
1113,
1114,
1115,
1116,
1117,
1118,
1119,
1140,
1141,
1142,
1143,
1144,
1145,
1146,
1147,
1148,
1149,
1150)
--a
select * from dbo.DACFollowupQuestion where qid in (
4265,
4266,
4267
)
--b
select * from dbo.DACFollowupQuestion where qid in (
4268
)
--c
select * from dbo.DACFollowupQuestion where qid in (
4269)

--d
select * from dbo.DACFollowupQuestion where qid in (
4270,
4271,
4272
)

select * from dbo.DACFollowupQuestion where qid in (
4273,
4274,
4275
)

select * from dbo.DACFollowupQuestion where qid in (
4276,
4277
)

select * from dbo.DACFollowupQuestion where qid in (
4278)

select * from dbo.DACFollowupQuestion where qid in (
4279,
4280,
4281,
4282,
4283
)

select * from dbo.DACFollowupQuestion where qid in (
4284,
4285
)

select * from dbo.DACFollowupQuestion where qid in (
4286
)

select * from dbo.DACFollowupQuestion where qid in (
4287,
4288
)

--Final ic  - No follow - need to add
select * from dbo.DACFollowupQuestion where qid in (
4472,
4473,
4474
)

select * from dbo.DACFollowupQuestion where qid in (
4475
)

select * from dbo.DACFollowupQuestion where qid in (
4476
)

select * from dbo.DACFollowupQuestion where qid in (
4477,
4478,
4479
)

select * from dbo.DACFollowupQuestion where qid in (
4480,
4481,
4482
)

select * from dbo.DACFollowupQuestion where qid in (
4483,
4484
)

select * from dbo.DACFollowupQuestion where qid in (
4485
)

select * from dbo.DACFollowupQuestion where qid in (
4486,
4487,
4488,
4489,
4490
)

select * from dbo.DACFollowupQuestion where qid in (
4491,
4492
)

select * from dbo.DACFollowupQuestion where qid in (
4493
)

select * from dbo.DACFollowupQuestion where qid in (
4494,
4495
)

--1110	1053	B. Listed securities / price-sensitive information - 1
--1111	1053	C. Investment documentation - 1
--1113	1053	E. Engagement of consultants / advisors - 3
--1114	1053	F. Non-compete / restrictive covenants database - 2
--1115	1053	G. Information - 1
--1117	1053	I. Other -2
--1118	1053	J. Pre-Final IC -1
--1119	1053	K. Post-Final IC and prior to legal commitment -2

--4268 no question group id
--select * from dbo.dacfollowupquestion where qid = 4268
--section 8
select * from dbo.DACQuestionSubSection where QSecID in( 1054,1069)
SELECT * FROM DBO.DACQuestionBank WHERE QSecID in(1054,1069) and SecPartID in(1120,
1121,
1151,
1152)

select * from dbo.DACFollowupQuestion where qid in (
4289,
4290,
4291,
4292,
4293,
4294
)

select * from dbo.DACFollowupQuestion where qid in (
4295,
4296
)

--FInal ic -- No followup
select * from dbo.DACFollowupQuestion where qid in (
4496,
4497,
4498,
4499,
4500,
4501
)

select * from dbo.DACFollowupQuestion where qid in (
4502,
4503
)

--section 9
select * from dbo.DACQuestionSubSection where QSecID in( 1055,1070)
SELECT * FROM DBO.DACQuestionBank WHERE QSecID in(1055,1070) and SecPartID in(1122,
1153)


select * from dbo.DACFollowupQuestion where qid in (
4297,
4298,
4299,
4300,
4301,
4302,
4303,
4304,
4305
)

--Final IC - No follow up -- 
select * from dbo.DACFollowupQuestion where qid in (
4504,
4505,
4506,
4507,
4508,
4509,
4510,
4511,
4512
)

--section 10
select * from dbo.DACQuestionSubSection where QSecID in( 1056,1071)
SELECT * FROM DBO.DACQuestionBank WHERE QSecID in(1056,1071) and SecPartID in(1123,
1154)
--Sub-Section Part Id- 1123 Pre-ic sub section entry is not required. since it is not exist in excel file 
--but no questions are configured

--No pre ic in this section in excel

--Final IC - No follow up
select * from dbo.DACFollowupQuestion where qid in (
4513,
4514,
4515,
4516,
4517,
4518,
4519,
4520,
4521,
4522,
4523,
4524,
4525,
4526
)

--section 11
select * from dbo.DACQuestionSubSection where QSecID in( 1057,1072)
SELECT * FROM DBO.DACQuestionBank WHERE QSecID in(1057,1072) and SecPartID in(1058,
1059,
1060,
1061,
1155,
1156,
1157,
1158)
--1058 - A. Conflicts of interest - 2
--1059 - B. Related Party Transactions - 2
--1060 - C. Personal interests - 1
--1061 - D. Conflicts of interest - 1

select * from dbo.DACFollowupQuestion where qid in (
4306,
4307
)

select * from dbo.DACFollowupQuestion where qid in (
4308,
4309
)

select * from dbo.DACFollowupQuestion where qid in (
4310
)

select * from dbo.DACFollowupQuestion where qid in (
4311
)


--Final IC  - No link qids
select * from dbo.DACFollowupQuestion where qid in (
4527,
4528
)

select * from dbo.DACFollowupQuestion where qid in (
4529,
4530
)

select * from dbo.DACFollowupQuestion where qid in (
4531
)

select * from dbo.DACFollowupQuestion where qid in (
4532
)

--SECTION 12
select * from dbo.DACQuestionSubSection where QSecID in( 1058,1073)
SELECT * FROM DBO.DACQuestionBank WHERE QSecID in( 1058,1073) and SecPartID in(1062,
1159)

select * from dbo.DACFollowupQuestion where qid in (
4312,
4313,
4314
)

--Final IC  -- No link qids
select * from dbo.DACFollowupQuestion where qid in (
4533,
4534,
4535
)