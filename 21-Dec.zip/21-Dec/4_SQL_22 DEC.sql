USE [ActisFundChecklistUAT]
GO
/****** Object:  StoredProcedure [dbo].[DACAddQuestionDetails]    Script Date: 12/22/2020 11:45:53 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--Add Question details
ALTER PROCEDURE [dbo].[DACAddQuestionDetails]
    (                         
     @AssetId	INT,  
     @SectionId	  INT,
	 @SubSectionId INT,
	 @Staus		BIT,
	 @Mandatory BIT,
	 @QuestionGroupId INT,
	 @QuestionText			VARCHAR(MAX),
	 @YesFollowupText			VARCHAR(MAX),
	 @NoFollowupText			VARCHAR(MAX),
	 @NoteRefText			VARCHAR(MAX),
	 @IsLPSpecific TINYINT,
	 @LP TINYINT,
	 @Metric VARCHAR(MAX),
	 @ClauseRef VARCHAR(MAX),
	 @QuestionNo VARCHAR(10),
	 @ProcessGroupID INT
    )                                                          
AS   
                                                            
BEGIN   
	DECLARE @QuestionMaxId BIGINT
	DECLARE @Questionid BIGINT
	DECLARE @TotalActiveQuestions INT

	DECLARE @QSec BIGINT
	DECLARE @SecPart BIGINT
	DECLARE @QId BIGINT

	-- Get Pre Ic QID start
	 select @QSec = QSecID from DACQuestionSections 
     where AssetID = @AssetId and ProcessGroupID = 1 and
     SectionHeading = (select SectionHeading from DACQuestionSections where QSecID = @SectionId)

     select @SecPart = SecPartID from DACQuestionSubSection 
     where QSecID = @QSec and
     SubSecHeadingText = (select SubSecHeadingText from DACQuestionSubSection where SecPartID = @SubSectionId)

     select Top 1 @QId = (QID) from DACQuestionBank where QSecID = @QSec and SecPartID = @SecPart and QusetionNo = @QuestionNo

   --Get Pre Ic QID end

	INSERT INTO [dbo].[DACQuestionBank] 
	(
			[QusetionNo]  --e.g.FUN-XX31-01
           ,[QuestionText]
           ,[DisplayOrder]
           ,[IsQuestionHeading]
           ,[IsActive]
           ,[IsCompulsory]
           ,[IsSubQuestion]
           --,[ParentQID]
           ,[AssetID]
           ,[QSecID]
           ,[SecPartID]
           ,[QuestionGroupID]  
           ,[PreIC_QID]
           ,[IsLpSpecific]
           ,[LP]
           ,[Metric]
           ,[ClauseReference]
		   ,ProcessGroupId 
	)
	VALUES(
	@QuestionNo
	,@QuestionText
	,1
	,0
	,@Staus
	,@Mandatory
	,0
	, @AssetId
	,@SectionId,
	@SubSectionId
	,@QuestionGroupId
	,@QId
	,@IsLPSpecific
	,@LP
	,@Metric
	,@ClauseRef
	,@ProcessGroupID
	)

	SET @Questionid = @@IDENTITY
	--Insert into Followup Text pass follow text
	INSERT [Dbo].[DACFollowupQuestion]
	(
	QID
	,ResponseType
	,FollowupText
	)
	VALUES
	(
	@Questionid
	,1
	,@YesFollowupText
	)
	--No Followup
	INSERT [Dbo].[DACFollowupQuestion]
	(
	QID
	,ResponseType
	,FollowupText
	)
	VALUES
	(
	@Questionid
	,0
	,@NoFollowupText
	)
	--Note/Reference 

	INSERT [dbo].[DACQuestionRefNote]
	(
	QID
	,QSecID
	,SecPartID
	,QuestionGroupID
	,ReferenceNote
	)
	VALUES
	(
	@Questionid
	,@SectionId
	,@SubSectionId
	,@QuestionGroupId
	,@NoteRefText
	)

	--UPDATE DACQuestionSubSection WITH TOTAL ACTIVE QUESTIONS: Starts
	IF (@AssetId = 4)
	BEGIN	
		SELECT @TotalActiveQuestions = COUNT(*) FROM DACQuestionBank 
			WHERE IsActive = 1 AND QSecID = @SectionId AND SecPartID = @SubSectionId AND AssetID = @AssetId

		UPDATE DACQuestionSubSection SET TotalQuestions = @TotalActiveQuestions 
			WHERE QSecID = @SectionId AND SecPartID = @SubSectionId
	END

	ELSE
	BEGIN
		SELECT @TotalActiveQuestions = COUNT(DISTINCT QuestionGroupID) FROM DACQuestionBank 
			WHERE IsActive = 1 AND QSecID = @SectionId AND SecPartID = @SubSectionId AND AssetID = @AssetId

		UPDATE DACQuestionSubSection SET TotalQuestions = @TotalActiveQuestions 
			WHERE QSecID = @SectionId AND SecPartID = @SubSectionId
	END
	--UPDATE DACQuestionSubSection WITH TOTAL ACTIVE QUESTIONS: Ends

END

SET ANSI_NULLS ON
GO

---------------------------------------------

ALTER PROCEDURE [dbo].[DACUpdateQuestionDetails]
    (                         
     @AssetId	INT,  
     @SectionId	  INT,
	 @SubSectionId INT,
	 @Staus		BIT,
	 @Mandatory BIT,
	 @QuestionGroupId INT,
	 @QuestionText			VARCHAR(MAX),
	 @YesFollowupText			VARCHAR(MAX),
	 @NoFollowupText			VARCHAR(MAX),
	 @NoteRefText			VARCHAR(MAX),
	 @IsLPSpecific TINYINT,
	 @LP TINYINT,
	 @Metric VARCHAR(MAX),
	 @ClauseRef VARCHAR(MAX),
	 @QID BIGINT,
	 @YesLinkQID BIGINT,
	 @NoLinkQID BIGINT,
	 @QuestionNo VARCHAR(10)
    )                                                          
AS                                                            
BEGIN   
	DECLARE @TotalActiveQuestions INT

	DECLARE @QSec BIGINT
	DECLARE @SecPart BIGINT
	DECLARE @QuesId BIGINT

	-- Get Pre Ic QID start
	 select @QSec = QSecID from DACQuestionSections 
     where AssetID = @AssetId and ProcessGroupID = 1 and
     SectionHeading = (select SectionHeading from DACQuestionSections where QSecID = @SectionId)

     select @SecPart = SecPartID from DACQuestionSubSection 
     where QSecID = @QSec and
     SubSecHeadingText = (select SubSecHeadingText from DACQuestionSubSection where SecPartID = @SubSectionId)

     select Top 1 @QuesId = (QID) from DACQuestionBank where QSecID = @QSec and SecPartID = @SecPart and QusetionNo = @QuestionNo

   --Get Pre Ic QID end

	UPDATE [dbo].[DACQuestionBank] SET
		[QuestionText] = @QuestionText
		,[QuestionGroupID] = @QuestionGroupId
		,[IsLpSpecific] = @IsLPSpecific
		,[LP]=@LP
		,[Metric] = @Metric
		--,[ParentQID] = @LinkQID
		,[QusetionNo] = @QuestionNo
		,[ClauseReference] = @ClauseRef
		,[IsActive]= @Staus
		,[IsCompulsory] = @Mandatory
		,[PreIC_QID] = @QuesId
		,IsSubQuestion =  CASE WHEN (@YesLinkQID != NULL OR @YesLinkQID !=0) OR (@NoLinkQID != NULL OR @NoLinkQID !=0) THEN  1 ELSE 0 END
	WHERE QID = @QID

	--Insert into Followup Text pass follow text
		UPDATE [dbo].[DACFollowupQuestion]
			 SET
				[FollowupText] = @YesFollowupText
				,[LinkedQID] = @YesLinkQID
			WHERE QID = @QID AND ResponseType =1

		UPDATE [dbo].[DACFollowupQuestion]
			SET
			[FollowupText] = @NoFollowupText
			,[LinkedQID] = @NoLinkQID
		WHERE QID = @QID AND ResponseType =0

		UPDATE [dbo].[DACQuestionRefNote]
			 SET
				[ReferenceNote] = @NoteRefText
			WHERE QID = @QID AND QSecID = @SectionId AND SecPartID = @SubSectionId

		--UPDATE DACQuestionSubSection WITH TOTAL ACTIVE QUESTIONS: Starts
		IF (@AssetId = 4)
		BEGIN	
			SELECT @TotalActiveQuestions = COUNT(*) FROM DACQuestionBank 
				WHERE IsActive = 1 AND QSecID = @SectionId AND SecPartID = @SubSectionId AND AssetID = @AssetId

			UPDATE DACQuestionSubSection SET TotalQuestions = @TotalActiveQuestions 
				WHERE QSecID = @SectionId AND SecPartID = @SubSectionId
		END

		ELSE
		BEGIN
			SELECT @TotalActiveQuestions = COUNT(DISTINCT QuestionGroupID) FROM DACQuestionBank 
				WHERE IsActive = 1 AND QSecID = @SectionId AND SecPartID = @SubSectionId AND AssetID = @AssetId

			UPDATE DACQuestionSubSection SET TotalQuestions = @TotalActiveQuestions 
				WHERE QSecID = @SectionId AND SecPartID = @SubSectionId
		END
		--UPDATE DACQuestionSubSection WITH TOTAL ACTIVE QUESTIONS: Ends
END

GO
---------------------------------------------
UPDATE DACFollowupQuestion SET LinkedQID = 4313 WHERE FollowupQID = 210
UPDATE DACFollowupQuestion SET LinkedQID = 4215 WHERE FollowupQID = 247 AND QID = 4206
UPDATE DACQuestionSubSection SET TotalQuestions = 14 WHERE QSecID = 1056 AND SecPartID = 1123
UPDATE DACQuestionSubSection SET TotalQuestions = 6 WHERE QSecID = 1050 AND SecPartID = 1106
UPDATE DACQuestionSubSection SET TotalQuestions = 24 WHERE QSecID = 1049 AND SecPartID = 1105
UPDATE DACFollowupQuestion SET LinkedQID = NULL WHERE QID = 4539 AND LinkedQID = 4540
UPDATE DACFollowupQuestion SET FollowupText = 'Proceed to A4.' WHERE QID = 4194 AND LinkedQID = 4195 AND ResponseType = 0
UPDATE DACFollowupQuestion SET FollowupText = 'Proceed to A6.' WHERE QID = 4196 AND LinkedQID = 4197 AND ResponseType = 0
UPDATE DACFollowupQuestion SET FollowupText = 'Proceed to A4.' WHERE QID = 4449 AND LinkedQID = 4450 AND ResponseType = 0
UPDATE DACFollowupQuestion SET FollowupText = 'Proceed to A6.' WHERE QID = 4451 AND LinkedQID = 4452 AND ResponseType = 0

/*
PRE-SECTION IDs:  1048, 1049, 1050, 1053, 1054, 1055, 1057, 1058   (GIVE THIS ONE-BY-ONE BELOW - REVERSE ORDER)
*/

DECLARE @Pre_SectionID	  BIGINT = 1058, --FILL ABOVE SECTION IDS ONE BY ONE
		@Pre_SubSectionID BIGINT,
		@Pre_QuesID BIGINT,
		@Fin_SectionID	  BIGINT,
		@Fin_SubSectionID BIGINT,
		@Fin_QuesID BIGINT,

		@FollowupText_0 NVARCHAR(MAX),
		@FollowupText_1 NVARCHAR(MAX),
		@LinkedQID_0 BIGINT,
		@LinkedQID_1 BIGINT
	
		DECLARE SUBSECTION_IDs CURSOR FOR SELECT DISTINCT SecPartID FROM [dbo].[DACQuestionSubSection] WHERE QSecID=@Pre_SectionID
		OPEN SUBSECTION_IDs
		FETCH NEXT FROM SUBSECTION_IDs INTO @Pre_SubSectionID
		WHILE @@FETCH_STATUS=0
		BEGIN
			-- LOOP START --
			DECLARE QIDs CURSOR FOR SELECT QID FROM [dbo].DACQuestionBank WHERE QSecID=@Pre_SectionID AND SecPartID = @Pre_SubSectionID AND AssetID=4 AND ProcessGroupID=1
			OPEN QIDs
			FETCH NEXT FROM QIDs INTO @Pre_QuesID
			WHILE @@FETCH_STATUS=0
			BEGIN					
				SELECT @FollowupText_0 = ''
				SELECT @FollowupText_1 = ''
				SELECT @LinkedQID_0 = NULL
				SELECT @LinkedQID_1 = NULL

				SELECT @Fin_QuesID = QID, @Fin_SectionID = QSecID, @Fin_SubSectionID = SecPartID 
				FROM DACQuestionBank WHERE PreIC_QID = @Pre_QuesID

				IF EXISTS (SELECT FollowupText FROM DACFollowupQuestion WHERE QID = @Pre_QuesID AND ResponseType = 0)
					SELECT @FollowupText_0 = FollowupText FROM DACFollowupQuestion WHERE QID = @Pre_QuesID AND ResponseType = 0

				IF EXISTS (SELECT FollowupText FROM DACFollowupQuestion WHERE QID = @Pre_QuesID AND ResponseType = 1)
					SELECT @FollowupText_1 = FollowupText FROM DACFollowupQuestion WHERE QID = @Pre_QuesID AND ResponseType = 1
				
				--LINKED QUESTION ID
				SELECT @LinkedQID_0 = FIN.QID FROM DACQuestionBank PRE, DACQuestionBank FIN 
				WHERE PRE.AssetID = 4 AND FIN.AssetID = 4
				AND PRE.QSecID = @Pre_SectionID AND PRE.SecPartID = @Pre_SubSectionID 
				AND FIN.QSecID = @Fin_SectionID AND FIN.SecPartID = @Fin_SubSectionID
				AND PRE.QusetionNo = FIN.QusetionNo 
				AND PRE.QID = (SELECT TOP 1 LinkedQID FROM DACFollowupQuestion WHERE QID = @Pre_QuesID AND ResponseType = 0)

				SELECT @LinkedQID_1 = FIN.QID FROM DACQuestionBank PRE, DACQuestionBank FIN 
				WHERE PRE.AssetID = 4 AND FIN.AssetID = 4
				AND PRE.QSecID = @Pre_SectionID AND PRE.SecPartID = @Pre_SubSectionID 
				AND FIN.QSecID = @Fin_SectionID AND FIN.SecPartID = @Fin_SubSectionID
				AND PRE.QusetionNo = FIN.QusetionNo 
				AND PRE.QID = (SELECT TOP 1 LinkedQID FROM DACFollowupQuestion WHERE QID = @Pre_QuesID AND ResponseType = 1)

				IF (@FollowupText_0 <> '')
					--INSERT INTO DBO.DACFollowupQuestion (QID, ResponseType, FollowupText, LinkedQID)
					SELECT @Fin_QuesID, 0, @FollowupText_0, @LinkedQID_0 

				IF (@FollowupText_1 <> '')
					--INSERT INTO DBO.DACFollowupQuestion (QID, ResponseType, FollowupText, LinkedQID)
					SELECT @Fin_QuesID, 1, @FollowupText_1, @LinkedQID_1 

				FETCH NEXT FROM QIDs INTO @Pre_QuesID
			END
			CLOSE QIDs
			DEALLOCATE QIDs	
			-- LOOP END -->
			FETCH NEXT FROM SUBSECTION_IDs INTO @Pre_SubSectionID
		END
		CLOSE SUBSECTION_IDs
		DEALLOCATE SUBSECTION_IDs	
------------------------------------------------------------------------

